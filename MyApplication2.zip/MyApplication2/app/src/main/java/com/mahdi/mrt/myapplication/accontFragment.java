package com.mahdi.mrt.myapplication;


import android.animation.Animator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;


import java.util.ArrayList;


import static android.content.Context.MODE_PRIVATE;
import static com.mahdi.mrt.myapplication.shenasFragment.Content;
import static com.mahdi.mrt.myapplication.shenasFragment.LINK;

/**
 */
public class accontFragment extends Fragment  {

    EditText link;
    AppCompatTextView txt_content;
    private EditText flink;


    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {

        View view = inflater.inflate( R.layout.fragment_accont , container , false );
        SharedPreferences userDetails = getContext().getSharedPreferences( "userdetails" , MODE_PRIVATE );
        String link = userDetails.getString(LINK, "");

        txt_content = (AppCompatTextView) view.findViewById( R.id.text_content );


        txt_content.setText( link );


        return view;
    }
    }



