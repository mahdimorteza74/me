package com.mahdi.mrt.myapplication;


import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends FragmentActivity {
    private EditText user,pass;




    private accontFragment accontFragment;
    private shenasFragment shenasFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        Button sabt=(Button)findViewById( R.id.button );
        accontFragment = new accontFragment();
        shenasFragment=new shenasFragment();
        shenasFragment shenasFragment = new shenasFragment();
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction().replace( R.id.fra , shenasFragment ,
                shenasFragment.getTag() ).commit();
sabt.setOnClickListener( new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        accontFragment  = new accontFragment();
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction().replace( R.id.fra , accontFragment ,
                accontFragment.getTag() ).commit();
    }
} );

//        sabt.setOnClickListener( new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                startActivity( new Intent( getApplicationContext() , Main2Activity.class ) );
//            }
//        } );
    }

}
