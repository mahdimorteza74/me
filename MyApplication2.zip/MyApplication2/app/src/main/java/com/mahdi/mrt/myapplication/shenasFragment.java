package com.mahdi.mrt.myapplication;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;

import static android.content.Context.MODE_PRIVATE;



public class shenasFragment extends Fragment {

Button sabt;
private EditText flink,fcontent;

    public static final String LINK = "LINK";
    public static final String Content = "Content";






    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_shenas , container , false );

        flink = (EditText) view.findViewById(R.id.link);
        fcontent = (EditText) view.findViewById(R.id.content);

        SharedPreferences userDetails = getContext().getSharedPreferences("userdetails", MODE_PRIVATE);

        SharedPreferences.Editor edit = userDetails.edit();
        String content = userDetails.getString(Content, "");

        String link = userDetails.getString(LINK, "");
        fcontent.setText(content);
        flink.setText(link);
        // Inflate the layout for this fragment
        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        SharedPreferences userDetails = getContext().getSharedPreferences("userdetails", MODE_PRIVATE);

         userDetails.edit().putString(LINK,flink.getText().toString()  ).commit();

        userDetails.edit().putString(Content,fcontent.getText().toString()  ).commit();

    }


}
